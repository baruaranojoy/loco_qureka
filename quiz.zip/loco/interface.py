from flask import Flask
from flask import request, render_template
from keras.models import model_from_json
import numpy as np
from keras import backend as K

def label(predictions):
	print ("##############################################")
	a = [0]*3
	maxx = max(predictions[0])
	pos = 0
	for m in range(len(predictions[0])):
	    if predictions[0][m] == maxx:
        	pos = m
        	break
	a[pos] = 1

	if a[0] == 1:
	    return 'A'
	elif a[1] == 1:
		return 'B'
	else:
		return 'C'

def predict(data):
	print (data)
	data = data.split(",")
	print (data)
	data_num = []
	for k in range(len(data)):
		data_num.append(ord(data[k][0]) - ord('A') + 1)

	if len(data_num) == 5:	
		json_file_6 = open('model/model_6th.json', 'r')
		loaded_model_json_6 = json_file_6.read()
		json_file_6.close()
		loaded_model_6 = model_from_json(loaded_model_json_6)
		loaded_model_6.load_weights("model/model_6th.h5")
		print("*******************Loaded model for 6th prediction from disk*******************")
		print(data_num)
		predictions = loaded_model_6.predict(np.array([data_num]))
		K.clear_session()
		return label(predictions)

	elif len(data_num) == 6:
		json_file_7 = open('model/model_7th.json', 'r')
		loaded_model_json_7 = json_file_7.read()
		json_file_7.close()
		loaded_model_7 = model_from_json(loaded_model_json_7)
		loaded_model_7.load_weights("model/model_7th.h5")
		print("*******************Loaded model for 7th prediction from disk*******************")
		print(data_num)
		predictions = loaded_model_7.predict(np.array([data_num]))
		K.clear_session()
		return label(predictions)
	
	elif len(data_num) == 7:
		json_file_8 = open('model/model_8th.json', 'r')
		loaded_model_json_8 = json_file_8.read()
		json_file_8.close()
		loaded_model_8 = model_from_json(loaded_model_json_8)
		loaded_model_8.load_weights("model/model_8th.h5")
		print("*******************Loaded model for 8th prediction from disk*******************")
		print(data_num)
		predictions = loaded_model_8.predict(np.array([data_num]))
		K.clear_session()
		return label(predictions)
	
	elif len(data_num) == 8:
		json_file_9 = open('model/model_9th.json', 'r')
		loaded_model_json_9 = json_file_9.read()
		json_file_9.close()
		loaded_model_9 = model_from_json(loaded_model_json_9)
		loaded_model_9.load_weights("model/model_9th.h5")
		print("*******************Loaded model for 9th prediction from disk*******************")
		print(data_num)
		predictions = loaded_model_9.predict(np.array([data_num]))
		K.clear_session()
		return label(predictions)
	
	elif len(data_num) == 9:	
		json_file_10 = open('model/model_10th.json', 'r')
		loaded_model_json_10 = json_file_10.read()
		json_file_10.close()
		loaded_model_10 = model_from_json(loaded_model_json_10)
		loaded_model_10.load_weights("model/model_10th.h5")
		print("*******************Loaded model for 10th prediction from disk*******************")
		print(data_num)
		predictions = loaded_model_10.predict(np.array([data_num]))
		K.clear_session()
		return label(predictions)
	
	else:
		return "Garbage !!"



app = Flask(__name__)

@app.route('/')
def welcome():
	return "Welcome! Please give input at proper location !"


@app.route('/prediction')
def my_form():
    return render_template('my-form.html')

@app.route('/prediction', methods=['POST'])
def my_form_post():
    text = request.form['text']
    processed_text = text.upper()
    return predict(processed_text)


if __name__ == '__main__':
    app.run(debug = True, host = '0.0.0.0', port=2018, threaded=True)